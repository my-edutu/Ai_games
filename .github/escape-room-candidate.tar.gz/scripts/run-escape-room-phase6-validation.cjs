'use strict';
const {createEscapeValidationBundle}=require('../dist/games/ai-escape-room/src/release/validation.js');const{scoreEscapeReadiness}=require('../dist/games/ai-escape-room/src/release/score.js');
const sha=process.env.CANDIDATE_SOURCE_SHA||'0123456789abcdef0123456789abcdef01234567';const bundle=createEscapeValidationBundle(sha),score=scoreEscapeReadiness(bundle);process.stdout.write(`${JSON.stringify({candidateSourceSha:sha,bundleChecksum:bundle.bundleChecksum,...score})}\n`);if(bundle.softwareVerdict!=='PASS'||score.softwareScore!==88)process.exitCode=1;
