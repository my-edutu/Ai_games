'use strict';
const {runEscapePhase5Chaos}=require('../dist/games/ai-escape-room/src/operations/chaos.js');
const result=runEscapePhase5Chaos(process.env.ESCAPE_CHAOS_SEED||'escape-room-phase5-chaos');process.stdout.write(`${JSON.stringify(result)}\n`);if(result.status!=='pass')process.exitCode=1;
