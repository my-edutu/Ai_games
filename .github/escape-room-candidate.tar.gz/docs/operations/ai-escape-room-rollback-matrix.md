# AI Escape Room Rollback Matrix

| Failure | Immediate action | Recovery | Boundary |
|---|---|---|---|
| Integrity/replay divergence | Quarantine | Roll back source/config and start fresh run | Fresh run required |
| Persistence/audit outage | Fail closed for mutation | Restore service, verify journal, resume | Existing state only if verified |
| Provider/moderation outage | Disable interactions | Reconnect provider and re-enable after health | No game reset |
| Renderer/capture failure | Safe scene | Rebuild renderer from latest valid public snapshot | No authority mutation |
| Crash loop | Fence writer, safe halt | Replace worker and verified restore | Lease generation changes |
