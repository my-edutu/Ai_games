# AI Escape Room Runbook

For provider outage, disable interactions and preserve autonomous simulation. For persistence or audit uncertainty, reject new authoritative/audience/operator mutations before state change. For renderer black/frozen/stale output, activate safe scene, restart renderer, restore latest verified snapshot and verify output before resume. For replay divergence or incompatible evidence, quarantine and require fresh-run boundary/rollback. For crash loops, open the restart breaker and safe-halt. Never convert technical recovery into a normal game loss.
