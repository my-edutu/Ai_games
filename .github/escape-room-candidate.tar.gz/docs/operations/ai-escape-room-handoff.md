# AI Escape Room Operations Handoff

Run the browser source with `npm run escape-room:stream`. Health endpoint: `/escape-room/health`. Before release freeze, run all Escape Room tests plus headless, campaign, stream self-test, chaos and Phase 6 validation against the exact candidate SHA. Preserve rollback source/config/content identities and collect R5 primary evidence using the evidence-intake rules.
