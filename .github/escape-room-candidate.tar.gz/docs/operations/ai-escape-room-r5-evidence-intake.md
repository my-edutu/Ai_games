# AI Escape Room R5 Evidence Intake

Every artifact must identify the exact candidate SHA and release checksum. Accept only production-reference capacity, credentialed provider tests, external safety/accessibility/audiovisual attestations, a real elapsed 72-hour soak, witnessed production recovery drills, a real elapsed seven-day canary and an external signed exact-candidate review. Synthetic/fixture/self-attested substitutes remain useful engineering evidence but award zero R5 points.
